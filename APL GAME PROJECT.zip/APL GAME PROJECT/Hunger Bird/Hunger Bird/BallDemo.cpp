/*
	author: S. M. Shahriar Nirjon
	last modified: August 8, 2008
*/
# include "iGraphics.h"

int ball_x, ball_y, ball_x1, ball_y1, ball_x2, ball_y2, ball_x3, ball_y3,ball_x4, ball_y4,ball_x5, ball_y5, ball_x6, ball_y6,ball_x7, ball_y7,
	ball_x8, ball_y8,ball_x9, ball_y9,ball_x10, ball_y10,ball_x11, ball_y11,ball_x12, ball_y12,ball_x13, ball_y13,ball_x14, ball_y14,ball_x15, ball_y15;
int dx, dy, dx1, dy1,dx2, dy2,dx3, dy3,dx4, dy4,dx5, dy5,dx6, dy6,dx7, dy7,dx8, dy8,
	dx9, dy9,dx10, dy10,dx11, dy11,dx12, dy12,dx13,dy13,dx14, dy14,dx15, dy15;

/* 
	function iDraw() is called again and again by the system.
*/
void iDraw()
{
	//place your drawing codes here	
	
	iClear();
	
	iSetColor(255, 100, 10);
	iFilledCircle(ball_x, ball_y, 7);

	iSetColor(255, 0, 0);
	iFilledCircle(ball_x1, ball_y1, 7);
	
	iSetColor(255, 100, 10);
	iFilledCircle(ball_x2, ball_y2, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x3, ball_y3, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x4, ball_y4, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x5, ball_y5, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x6, ball_y6, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x6, ball_y6, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x7, ball_y7, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x8, ball_y8, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x9, ball_y9, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x10, ball_y10, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x11, ball_y11, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x12, ball_y12, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x13, ball_y13, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x14, ball_y14, 7);

	iSetColor(255, 100, 10);
	iFilledCircle(ball_x15, ball_y15, 7);

	iSetColor(255, 255, 255);
	iText(10, 10, "Press p for pause, r for resume, END for exit.");
}

/* 
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here
}

/* 
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here	
	}
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here	
	}
}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed. 
*/
void iKeyboard(unsigned char key)
{
	if(key == 'p')
	{
		//do something with 'q'
		iPauseTimer(0);
	}
	if(key == 'r')
	{
		iResumeTimer(0);
	}
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use 
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6, 
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12, 
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP, 
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT 
*/
void iSpecialKeyboard(unsigned char key)
{

	if(key == GLUT_KEY_END)
	{
		exit(0);	
	}
	//place your codes for other keys here
}

void ballChange(){
	
	ball_x += dx;
	ball_y += dy;

	if(ball_x > 400 || ball_x < 0)dx = -dx;
	if(ball_y > 400 || ball_y < 0)dy = -dy;
	
	ball_x1 += dx1;
	ball_y1 += dy1;

	if(ball_x1 > 400 || ball_x1 < 0)dx1 = -dx1;
	if(ball_y1 > 400 || ball_y1 < 0)dy1 = -dy1;

	ball_x2 += dx2;
	ball_y2 += dy2;

	if(ball_x2 > 400 || ball_x2 < 0)dx2 = -dx2;
	if(ball_y2 > 400 || ball_y2 < 0)dy2 = -dy2;

	ball_x3 += dx3;
	ball_y3 += dy3;

	if(ball_x3 > 400 || ball_x3 < 0)dx3 = -dx3;
	if(ball_y3 > 400 || ball_y3 < 0)dy3 = -dy3;

	ball_x4 += dx4;
	ball_y4 += dy4;

	if(ball_x4 > 400 || ball_x4 < 0)dx4 = -dx4;
	if(ball_y4 > 400 || ball_y4 < 0)dy4 = -dy4;

	ball_x5 += dx5;
	ball_y5 += dy5;

	if(ball_x5 > 400 || ball_x5 < 0)dx5 = -dx5;
	if(ball_y5 > 400 || ball_y5 < 0)dy5 = -dy5;

	ball_x6 += dx6;
	ball_y6 += dy6;

	if(ball_x6 > 400 || ball_x6 < 0)dx6 = -dx6;
	if(ball_y6 > 400 || ball_y6< 0)dy6 = -dy6;
	
	ball_x7 += dx7;
	ball_y7 += dy7;

	if(ball_x7 > 400 || ball_x7 < 0)dx7 = -dx7;
	if(ball_y7 > 400 || ball_y7 < 0)dy7 = -dy7;

	ball_x8 += dx8;
	ball_y8 += dy8;

	if(ball_x8 > 400 || ball_x8 < 0)dx8 = -dx8;
	if(ball_y8 > 400 || ball_y8 < 0)dy8 = -dy8;

	ball_x9 += dx9;
	ball_y9 += dy9;

	if(ball_x9 > 400 || ball_x9 < 0)dx9 = -dx9;
	if(ball_y9 > 400 || ball_y9 < 0)dy9 = -dy9;

	ball_x10 += dx10;
	ball_y10 += dy10;

	if(ball_x10 > 400 || ball_x10 < 0)dx10 = -dx10;
	if(ball_y10 > 400 || ball_y10 < 0)dy10 = -dy10;

	ball_x11 += dx11;
	ball_y11 += dy11;

	if(ball_x11 > 400 || ball_x11 < 0)dx11 = -dx11;
	if(ball_y11 > 400 || ball_y11 < 0)dy11 = -dy11;

	ball_x12 += dx12;
	ball_y12 += dy12;

	if(ball_x12 > 400 || ball_x12 < 0)dx12 = -dx12;
	if(ball_y12 > 400 || ball_y12 < 0)dy12 = -dy12;

	ball_x13 += dx13;
	ball_y13 += dy13;

	if(ball_x13 > 400 || ball_x13 < 0)dx13 = -dx13;
	if(ball_y13 > 400 || ball_y13 < 0)dy13 = -dy13;

	ball_x14 += dx14;
	ball_y14 += dy14;

	if(ball_x14 > 400 || ball_x14 < 0)dx14 = -dx14;
	if(ball_y14 > 400 || ball_y14 < 0)dy14 = -dy14;

	ball_x15 += dx15;
	ball_y15 += dy15;

	if(ball_x15 > 400 || ball_x15 < 0)dx15 = -dx15;
	if(ball_y15 > 400 || ball_y15 < 0)dy15 = -dy15;

	
}
int main()
{
	//place your own initialization codes here. 
	iSetTimer(60, ballChange);
	dx = 2;
	dy = 3;

	dx1 = 5;
	dy1 = 2;

	dx2 = 1;
	dy2 = 3;

	dx3 = 2;
	dy3 = 1;


	dx4 = 2;
	dy4 = 4;

	dx5 = 1;
	dy5 = 5;

	dx6 = 1;
	dy6 = 4;

	dx7 = 5;
	dy7 = 3;

	dx8 = 6;
	dy8 = 7;

	dx9 = 4;
	dy9 = 1;

	dx10 = 5;
	dy10 = 1;

	dx11 = 1;
	dy11 = 4;

	dx12 = 6;
	dy12 = 1;

	dx13 = 2;
	dy13 = 5;

	dx14 = 4;
	dy14 = 3;

	dx15 = 5;
	dy15 = 4;
	
	iInitialize(400, 400, "BallDemo");
	return 0;
}	