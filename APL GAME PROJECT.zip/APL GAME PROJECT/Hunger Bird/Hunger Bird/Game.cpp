
# include "iGraphics.h"

	int dpicx = 0;
	int dpicy = 0;

	int dx = 2;
	int dy = 3;

	int dx1 = 5;
	int dy1 = 2;

	int dx2 = 1;
	int dy2 = 3;

	int dx3 = 2;
	int dy3 = 1;

	int dx4 = 2;
	int dy4 = 4;

	int dx5 = 1;
	int dy5 = 5;

	int dx6 = 1;
	int dy6 = 4;

	int dx7 = 5;
	int dy7 = 3;

	int dx8 = 3;
	int dy8 = 1;

	int dx9 = 4;
	int dy9 = 1;

	int dx10 = 5;
	int dy10 = 1;

	int dx11 = 1;
	int dy11 = 4;

	int dx12 = 6;
	int dy12 = 1;

	int dx13 = 2;
	int dy13 = 5;

	int dx14 = 4;
	int dy14 = 3;

	int dx15 = 5;
	int dy15 = 4;

	int pic_x = 256;
	int pic_y = 256;
	


int w = 1024, h = 550;

int buttonstart_x = 26, buttonstart_y = 32, bsh = 64, bsw = 256;
int originalstart_x = buttonstart_x, originalstart_y = buttonstart_y;

int buttonanimate = 5;

int ball_x, ball_y, ball_x1, ball_y1, ball_x2 , ball_y2, ball_x3, ball_y3, ball_x4, ball_y4,ball_x5, ball_y5, ball_x6, ball_y6, ball_x7, ball_y7,
	ball_x8, ball_y8, ball_x9, ball_y9, ball_x10, ball_y10, ball_x11, ball_y11, ball_x12, ball_y12, ball_x13, ball_y13, ball_x14, ball_y14, ball_x15, ball_y15;

//int dx, dy, dx1, dy1, dx2, dy2, dx3, dy3, dx4, dy4, dx5, dy5, dx6, dy6, dx7, dy7, dx8, dy8,
	//dx9, dy9, dx10, dy10,dx11, dy11,dx12, dy12, dx13, dy13, dx14, dy14, dx15, dy15, dpicx, dpicy;

//int pic_x, pic_y;

int speed = 15;

int flag_start_button_down = 0;

int startgame = 0; int wingame= 0 ;
int crush= 0;

char tscore[15] = { "Score: " };
int score = 0, highscore,temp;
char sscore[1], shighscore[1],score_num[100];

bool ball = true;


bool food1= true, food2= true , food3 = true, food4= true, food5= true , food6 = true, food7= true, food8= true , food9 = true;
bool food10= true, food11 = true, food12= true , food13 = true, food14= true, food15= true ;
/* 
	function iDraw() is called again and again by the system.
*/
void iDraw()
{
	//place your drawing codes here
	iClear ();
	iShowBMP (0, 0, "Picture/b1.bmp");
	iShowBMP (512, 0, "Picture/b2.bmp");

	iShowBMP (buttonstart_x, buttonstart_y, "Picture/start1.bmp");

	if (startgame==1)
	{
		iClear();

		iShowBMP(pic_x, pic_y, "bird.bmp");
		

		//BIRDS FOOD

		iSetColor(255,0,0);
		if (food1 == true)
		{
		iFilledRectangle(100,110,16,16);
		}

		iSetColor(255,0,0);
		if (food2 == false){
		iFilledRectangle(200,110,16,16);
		}

		iSetColor(255,0,0);
		if (food3 == false){
		iFilledRectangle(200,300,16,16);
		}

		iSetColor(255,0,0);
		if (food4 == false){
		iFilledRectangle(500,400,16,16);
		}

		iSetColor(255,0,0);
		if (food5 == false){
		iFilledRectangle(100,500,16,16);
		}

		iSetColor(255,0,0);
		if (food6 == false){
		iFilledRectangle(300,500,16,16);
		}

		iSetColor(255,0,0);
		if (food7 == false){
		iFilledRectangle(250,350,16,16);
		}

		iSetColor(255,0,0);
		if (food8 == false){
		iFilledRectangle(400,100,16,16);
		}

		iSetColor(255,0,0);
		if (food9 == false){
		iFilledRectangle(200,400,16,16);
		}

		iSetColor(255,0,0);
		if (food10 == false){
		iFilledRectangle(150,250,16,16);
		}

		iSetColor(255,0,0);
		if (food11 == false){
		iFilledRectangle(350,250,16,16);
		}

		iSetColor(255,0,0);
		if (food12 == false){
		iFilledRectangle(250,250,16,16);
		}

		iSetColor(255,0,0);
		if (food13 == false){
		iFilledRectangle(150,150,16,16);
		}

		iSetColor(255,0,0);
		if (food14 == false){
		iFilledRectangle(350,350,16,16);
		}

		iSetColor(255,0,0);
		if (food15 == false){
		iFilledRectangle(450,450,16,16);
		}

	
		
		//for ball
	
		iSetColor(255, 0, 0);
		if (ball == true){
		iShowBMP(ball_x, ball_y, "picture/x.bmp" );
		
		
		iSetColor(255, 100, 10);
		iShowBMP(ball_x1, ball_y1, "picture/x.bmp" );
		
		iSetColor(255, 100, 10);
		iShowBMP(ball_x2, ball_y2, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x3, ball_y3, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x4, ball_y4, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x5, ball_y5, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x6, ball_y6, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x7, ball_y7, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x8, ball_y8, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x9, ball_y9, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x10, ball_y10, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x11, ball_y11, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x12, ball_y12, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x13, ball_y13, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x14, ball_y14, "picture/x.bmp" );

		iSetColor(255, 100, 10);
		iShowBMP(ball_x15, ball_y15, "picture/x.bmp" );
		}

		iSetColor(53, 162, 193);
		iText(10, 500, "SCORE : ", GLUT_BITMAP_9_BY_15);
		_itoa_s(score,score_num,10);
		iText(76,499,score_num, GLUT_BITMAP_9_BY_15);

		iSetColor(255, 255, 255);
		iText(10, 10, "Press p for pause, r for resume, END for exit.");

		}
		
	
		if(wingame==1)
		{
		iClear ();
		iShowBMP(0,0, "picture/youwin.bmp");

		iSetColor(53, 162, 193);
		iText(600 , 190,score_num, GLUT_BITMAP_TIMES_ROMAN_24);
		iText(420 , 190, "YOUR SCORE : ", GLUT_BITMAP_TIMES_ROMAN_24);

		startgame =0;
		}


	   if (crush==1)
	   {
		iClear ();
		iShowBMP(0,0, "picture/gameover.bmp");

		iText(600 , 50,score_num, GLUT_BITMAP_TIMES_ROMAN_24);
		iText(420 , 50, "YOUR SCORE : ", GLUT_BITMAP_TIMES_ROMAN_24);

	   }
	
	}

/* 
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here
}

/* 
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouse(int button, int state, int mx, int my)
{
	//Start button animation
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if (mx > buttonstart_x && mx < (buttonstart_x + bsw) && my > buttonstart_y && my < (buttonstart_y + bsh))
		{
			buttonstart_x += buttonanimate;
			buttonstart_y -= buttonanimate;
			flag_start_button_down = 1;
			//startgame=1;
			
		
		}
	} 

	else if (button == GLUT_LEFT_BUTTON || state == GLUT_UP)
	{
		if (flag_start_button_down == 1)
		{
			buttonstart_x = originalstart_x;
			buttonstart_y = originalstart_y;
			startgame = 1;
		
			flag_start_button_down = 0;
		}
	}
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here	
	}
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		//place your codes here	
	}
}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed. 
*/
void iKeyboard(unsigned char key)
{
	if(key == 'p')
	{
		//do something with 'q'
		iPauseTimer(0);
	}
	if(key == 'r')
	{
		iResumeTimer(0);
	}
	if(key == 'm')
	{
		PlaySound(0,0,0);
	}
	if(key == 'n')
	{
		PlaySound ("music\\1094437108",NULL,SND_LOOP |  SND_ASYNC );
	}
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use 
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6, 
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12, 
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP, 
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT 
*/
void iSpecialKeyboard(unsigned char key)
{

	if(key == GLUT_KEY_END)
	{
		exit(0);	
	}
	if(key == GLUT_KEY_END)
	{
		exit(0);	
	}
	if(key == GLUT_KEY_LEFT)
	{
		if (pic_x-2 >= 0)
			pic_x -= speed;
	}
	if(key == GLUT_KEY_RIGHT)
	{
		if (pic_x + 32 <= 1024)
			pic_x += speed;
	}
	if(key == GLUT_KEY_UP)
	{
		if (pic_y + 32 <= 550)
		pic_y += speed;
	}
	if(key == GLUT_KEY_DOWN)
	{
		if (pic_y -5 >= 0)
		pic_y -= speed;
	}


	//place your codes for other keys here
}



void movement()
{

	//Eat food
	if(startgame==1)
	{
		if (food1 == true && pic_x >= 80 && (pic_x + 32 >= 80) && pic_x <= 80+32 && pic_y >= 90 && pic_y <= 90+32){
		score += 5;
		food1 = false;
		food2 = false ;
		//wingame=1;
			
	}

	if (food2 == false && pic_x >= 180 && (pic_x + 32 >= 180) && pic_x <= 180+32 && pic_y >= 90 && pic_y <= 90+32){
		score += 5;
		food2 = true;
		food3 = false ;
	}

	if (food3 == false && pic_x >= 180 && pic_x+32 >180 && pic_x <= 180+32 && pic_y >= 280 && pic_y <= 280+32){
		score += 5;
		food3 = true;
		food4 = false ;
	}

	if (food4 == false && pic_x >= 480 && pic_x <= 480+32 && pic_y >= 380 && pic_y <= 380+32){
		score += 5;
		food4 = true;
		food5 = false ;
	}

	if (food5 == false && pic_x >= 80 && pic_x <= 80+32 && pic_y >= 480 && pic_y <= 480+32){
		score += 5;
		food5 = true;
		food6 = false ;
	}

	if (food6 == false && pic_x >= 280 && pic_x <= 280+32 && pic_y >= 480 && pic_y <= 480+32){
		score += 5;
		food6 = true;
		food7 = false ;
	}

	if (food7 == false && pic_x >= 230 && pic_x <= 230+32 && pic_y >= 330 && pic_y <= 330+32){
		score += 5;
		food7 = true;
		food8 = false ;
	}

	if (food8 == false && pic_x >= 380 && pic_x <= 380+32 && pic_y >= 80 && pic_y <= 80+32){
		score += 5;
		food8 = true;
		food9 = false ;
	}

	if (food9 == false && pic_x >= 180 && pic_x <= 180+32 && pic_y >= 380 && pic_y <= 380+32){
		score += 5;
		food9 = true;
		food10 = false ;
	}

	if (food10 == false && pic_x >= 130 && pic_x <= 130+32 && pic_y >= 230 && pic_y <= 230+32){
		score += 5;
		food10 = true;
		food11 = false ;
	}

	if (food11 == false && pic_x >= 330 && pic_x <= 330+32 && pic_y >= 230 && pic_y <= 230+32){
		score += 5;
		food11 = true;
		food12 = false ;
	}

	if (food12 == false && pic_x >= 230 && pic_x <= 230+32 && pic_y >= 230 && pic_y <= 230+32){
		score += 5;
		food12 = true;
		food13 = false ;
	}


	if (food13 == false && pic_x >= 130 && pic_x <= 130+32 && pic_y >= 130 && pic_y <= 130+32){
		score += 5;
		food13 = true;
		food14 = false ;
	}

	if (food14 == false && pic_x >= 330 && pic_x <= 330+32 && pic_y >= 330 && pic_y <= 330+32){
		score += 5;
		food14 = true;
		food15 = false ;
	}
	 
	if (food15 == false && pic_x >= 430 && pic_x <= 430+32 && pic_y >= 430 && pic_y <= 430+32){
		score += 5;
		food15 = true;
		iPauseTimer(0);
		wingame = 1;
	}

	//crush ball

	if(ball == true && pic_x >= ball_x- 10 && pic_x <= ball_x -10+16 && pic_y >= ball_y-10 && pic_y <= ball_y-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x1 -10 && pic_x <= ball_x1 -10+16 && pic_y >= ball_y1-10 && pic_y <= ball_y1-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x2-10 && pic_x <= ball_x2 -10+16 && pic_y >= ball_y2 -10 && pic_y <= ball_y2 -10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x3-10 && pic_x <= ball_x3 -10+16 && pic_y >= ball_y3-10 && pic_y <= ball_y3-10+16){
		crush=1;}
	
	if(ball == true && pic_x >= ball_x4-10 && pic_x <= ball_x4 -10+16 && pic_y >= ball_y4-10 && pic_y <= ball_y4-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x5-10 && pic_x <= ball_x5 -10+16 && pic_y >= ball_y5-10 && pic_y <= ball_y5-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x6-10 && pic_x <= ball_x6 -10+16 && pic_y >= ball_y6-10 && pic_y <= ball_y6-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x7-10 && pic_x <= ball_x7 -10+16 && pic_y >= ball_y7-10 && pic_y <= ball_y7-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x8-10 && pic_x <= ball_x8 -10+16 && pic_y >= ball_y8-10 && pic_y <= ball_y8-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x9-10 && pic_x <= ball_x9 -10+16 && pic_y >= ball_y9-10 && pic_y <= ball_y9-10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x10-10 && pic_x <= ball_x10 -10+16 && pic_y >= ball_y10-10 && pic_y <= ball_y10 - 10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x11-10 && pic_x <= ball_x11 -10+16 && pic_y >= ball_y11 -10 && pic_y <= ball_y11 -10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x12 -10 && pic_x <= ball_x12 -10+16 && pic_y >= ball_y12 -10 && pic_y <= ball_y12 -10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x13 -10 && pic_x <= ball_x13 -10+16 && pic_y >= ball_y13 -10 && pic_y <= ball_y13 -10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x14 -10 && pic_x <= ball_x14 -10+16 && pic_y >= ball_y14 -10 && pic_y <= ball_y14 -10+16){
		crush=1;}

	if(ball == true && pic_x >= ball_x15 -10 && pic_x <= ball_x15 -10+16 && pic_y >= ball_y15 -10 && pic_y <= ball_y15 -10+16){
		crush=1;}


	//ball change

	ball_x += dx;
	ball_y += dy;

	if(ball_x > w || ball_x < 0)dx = -dx;
	if(ball_y > h || ball_y < 0)dy = -dy;
	
	ball_x1 += dx1;
	ball_y1 += dy1;

	if(ball_x1 > w || ball_x1 < 0)dx1 = -dx1;
	if(ball_y1 > h || ball_y1 < 0)dy1 = -dy1;

	ball_x2 += dx2;
	ball_y2 += dy2;

	if(ball_x2 > w || ball_x2 < 0)dx2 = -dx2;
	if(ball_y2 > h || ball_y2 < 0)dy2 = -dy2;

	ball_x3 += dx3;
	ball_y3 += dy3;

	if(ball_x3 > w || ball_x3 < 0)dx3 = -dx3;
	if(ball_y3 > h || ball_y3 < 0)dy3 = -dy3;

	ball_x4 += dx4;
	ball_y4 += dy4;

	if(ball_x4 > w || ball_x4 < 0)dx4 = -dx4;
	if(ball_y4 > h || ball_y4 < 0)dy4 = -dy4;

	ball_x5 += dx5;
	ball_y5 += dy5;

	if(ball_x5 > w || ball_x5 < 0)dx5 = -dx5;
	if(ball_y5 > h || ball_y5 < 0)dy5 = -dy5;

	ball_x6 += dx6;
	ball_y6 += dy6;

	if(ball_x6 > w || ball_x6 < 0)dx6 = -dx6;
	if(ball_y6 > h || ball_y6< 0)dy6 = -dy6;
	
	ball_x7 += dx7;
	ball_y7 += dy7;

	if(ball_x7 > w || ball_x7 < 0)dx7 = -dx7;
	if(ball_y7 > h || ball_y7 < 0)dy7 = -dy7;

	ball_x8 += dx8;
	ball_y8 += dy8;

	if(ball_x8 > w || ball_x8 < 0)dx8 = -dx8;
	if(ball_y8 > h || ball_y8 < 0)dy8 = -dy8;

	ball_x9 += dx9;
	ball_y9 += dy9;

	if(ball_x9 > w || ball_x9 < 0)dx9 = -dx9;
	if(ball_y9 > h || ball_y9 < 0)dy9 = -dy9;

	ball_x10 += dx10;
	ball_y10 += dy10;

	if(ball_x10 > w || ball_x10 < 0)dx10 = -dx10;
	if(ball_y10 > h || ball_y10 < 0)dy10 = -dy10;

	ball_x11 += dx11;
	ball_y11 += dy11;

	if(ball_x11 > w || ball_x11 < 0)dx11 = -dx11;
	if(ball_y11 > h || ball_y11 < 0)dy11 = -dy11;

	ball_x12 += dx12;
	ball_y12 += dy12;

	if(ball_x12 > w || ball_x12 < 0)dx12 = -dx12;
	if(ball_y12 > h || ball_y12 < 0)dy12 = -dy12;

	ball_x13 += dx13;
	ball_y13 += dy13;

	if(ball_x13 > w || ball_x13 < 0)dx13 = -dx13;
	if(ball_y13 > h || ball_y13 < 0)dy13 = -dy13;

	ball_x14 += dx14;
	ball_y14 += dy14;

	if(ball_x14 > w || ball_x14 < 0)dx14 = -dx14;
	if(ball_y14 > h || ball_y14 < 0)dy14 = -dy14;

	ball_x15 += dx15;
	ball_y15 += dy15;

	if(ball_x15 > w || ball_x15 < 0)dx15 = -dx15;
	if(ball_y15 > h || ball_y15 < 0)dy15 = -dy15;

	
}
	}
	
int main()
{
	//place your own initialization codes here. 
	
		
	iSetTimer(60, movement);
	


	srand(time(NULL));	
	PlaySound ("music\\11",NULL,SND_LOOP |  SND_ASYNC ); 

	iInitialize(w, h, "HANGRY BIRD");
	return 0;
}	